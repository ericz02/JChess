package chess;

/**Enumeration type to represent colors.
 * @author Kevin Reid, Jerry Aviles, & Eric Zheng.
 * @date April 8 - May 3, 2022
 */

public enum Color { BLACK, WHITE }
